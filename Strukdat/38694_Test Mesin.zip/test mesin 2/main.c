#include "header.h"

int main(){
	list L;
	createlist(&L);
	biodat nami[5];
	int i;
	for(i=0 ; i<5 ; i++){
		scanf("%s %s %s", &nami[i].nama, &nami[i].umur, &nami[i].jk);
	}
	
	printf("=====\n");
	addFirst(nami[0].nama, nami[0].umur, nami[0].jk, &L);
	addLast(nami[1].nama, nami[1].umur, nami[1].jk, &L);
	addFirst(nami[2].nama, nami[2].umur, nami[2].jk, &L);
	printElement(L);
	printf("=====\n");
	
	addAfter(L.first->next, nami[3].nama, nami[3].umur, nami[3].jk, &L);
	printElement(L);
	printf("=====\n");
	
	delAfter(L.first->next, &L);
	addLast(nami[4].nama, nami[4].umur, nami[4].jk, &L);
	printElement(L);
	printf("=====\n");
	delFirst(&L);
	delLast(&L);
	printElement(L);
	printf("=====\n");
	delAll(&L);
	printElement(L);
	printf("\n=====\n");
	
	
	
	
	
	
	return 0;
}