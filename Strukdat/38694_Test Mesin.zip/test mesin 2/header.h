#include <stdio.h>
#include <malloc.h>
#include <string.h>

typedef struct{
	char nama[10];
	char umur[3];
	char jk[2];
}biodat;

typedef struct elmt *alamatelmt;
typedef struct elmt{
	biodat elmt;
	alamatelmt next;
}elemen;

typedef struct{
	elemen *first;
}list;

void createlist(list *L);
int countElement(list L);
void addFirst(char nama[], char umur[], char jk[], list *L);
void addAfter(elemen *prev, char nama[], char umur[], char jk[], list *L);
void addLast(char nama[], char umur[], char jk[], list *L);
void delFirst(list *L);
void delAfter(elemen *prev, list *L);
void delLast(list *L);
void printElement(list L);
void delAll(list *L);