#include "header.h"

void createlist(list *L){
	(*L).first = NULL;
}

int countElement(list L){
	int hasil=0;
	
	if(L.first != NULL){
		//list tidak kosong
		elemen *elmt;
		
		//inisialisasi
		elmt=L.first;
		
		while(elmt != NULL){
			//proses
			hasil=hasil+1;
			
			//iterasi
			elmt = elmt->next;
		}
	}
	return hasil;
}

void addFirst(char nama[], char umur[], char jk[], list *L){
	elemen *baru;
	baru = (elemen *) malloc (sizeof(elemen));
	strcpy(baru->elmt.nama,nama);
	strcpy(baru->elmt.umur,umur);
	strcpy(baru->elmt.jk,jk);
	if((*L).first == NULL){
		baru->next = NULL;
	}
	else{
		baru->next = (*L).first;
	}
	(*L).first = baru;
	baru = NULL;
}

void addAfter(elemen *prev, char nama[], char umur[], char jk[], list *L){
	elemen *baru;
	baru = (elemen *) malloc (sizeof(elemen));
	strcpy(baru->elmt.nama,nama);
	strcpy(baru->elmt.umur,umur);
	strcpy(baru->elmt.jk,jk);
	if(prev->next == NULL){
		baru->next = NULL;
	}
	else{
		baru->next = prev->next;
	}
	prev->next = baru;
	baru = NULL; 
}

void addLast(char nama[], char umur[], char jk[], list *L){
	if((*L).first == NULL){
		//jika list adalah list kosong
		addFirst(nama,umur,jk,L);
	}
	else{
		//jika list tidak kosong
		//mencari element terakhir list
		elemen *prev = (*L).first;
		while(prev->next != NULL){
			//iterasi
			prev=prev->next;
		}
		addAfter(prev,nama,umur,jk,L);
	}
}

void delFirst(list *L){
	if((*L).first != NULL){
		//jika list kosong
		elemen *hapus = (*L).first;
		if(countElement(*L) == 1){
			(*L).first=NULL;
		}
		else{
			(*L).first= (*L).first->next;
			hapus->next;
		}
		free(hapus);
	}
}

void delAfter(elemen *prev, list *L){
	elemen *hapus = prev->next;
	if(hapus != NULL){
		if(hapus->next == NULL){
			prev->next =NULL;
		}
		else{
			prev->next = hapus->next;
			hapus->next=NULL;
		}
		//pengosongan elemen
		free(hapus);
	}
}

void delLast(list *L){
	if((*L).first != NULL){
		//jika list tidak kosong
		if(countElement(*L) ==1){
			//list terdiri darisatu elemen
			delFirst(L);
		}
		else{
			//mencari elemen terakhir
			elemen *last = (*L).first;
			elemen *prev;
			while(last->next != NULL){
				//iterasi
				prev= last;
				last=last->next;
			}
			delAfter(prev,L);
		}
	}
}

void printElement(list L){
	if(L.first != NULL){
		//jika list tidak kosong
		//inisialisasi
		elemen *elmt = L.first;
		int i=1;
		while(elmt != NULL){
			//proses
			printf("%s %s %s\n",elmt->elmt.nama, elmt->elmt.umur, elmt->elmt.jk);
			elmt = elmt -> next;
			i++;
		}
	}
	else{
		//proses jika list kosong
		printf("List Kosong");
	}
}

void delAll(list *L){
	if(countElement(*L) != 0){
		int i;
		for(i = countElement(*L) ; i>=1 ; i--){
			//proses menghapus elemen list
			delLast(L);
		}
	}
}