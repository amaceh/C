#include <stdio.h>
#include <string.h>
#include <malloc.h>

typedef struct{
	char nim[10];
}mahasiswa;

typedef struct{
	char kode[50];
}matKul;

typedef struct eklm *alamatkolom;
typedef struct eklm{
	matKul elmt;
	alamatkolom next;
}eKolom;

typedef struct ebr *alamatbaris;
typedef struct ebr{
	mahasiswa elmt;
	eKolom *co1;
	alamatbaris next;
}eBaris;

typedef struct{
	eBaris *first;
}list;

void createList(list *L);
int countElementB(list L);
int countElementK(eBaris L);
void addFirstB(char nim[],  list*L);
void addFirstK(char kode[],  eBaris *L);
void addAfterB(eBaris *prev, char nim[]);
void addAfterK(eKolom *prev, char kode[]);
void addLastB(char nim[],  list *L);
void addLastK(char kode[],  eBaris *L);
void delFirstB(list *L);
void delFirstK(eBaris *L);
void delAfterB(eBaris *prev);
void delAfterK(eKolom *prev);
void delLastB(list *L);
void delLastK(eBaris *L);
void printElement(list L);
void delAllB(list *L);
void delAllK(eBaris *L);