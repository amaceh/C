#include "header.h"

int main(){
	list L;
	eBaris *sugu;
	createList(&L);
	int i,n,p;
	scanf("%d",&n);
	mahasiswa huruf;
	matKul tulisan;
	for (i = 0; i < n; ++i)
	{
		scanf("%s",huruf.nim);
		addLastB(huruf.nim,&L);
		if(i==0){
			sugu=L.first;
		}else{
			sugu=sugu->next;
		}
		
		scanf("%s",tulisan.kode);
		addLastK(tulisan.kode,sugu);

		scanf("%s",tulisan.kode);
		addAfterK(sugu->co1, tulisan.kode);
		
		scanf("%s",tulisan.kode);
		addLastK(tulisan.kode,sugu);
		
		scanf("%s",tulisan.kode);
		addFirstK(tulisan.kode,sugu);
	}
	printElement(L);
	
	return 0;
}