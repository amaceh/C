#include "header.h"

void createList(list *L){
	(*L).first = NULL;
}

int countElementB(list L){
	int hasil = 0;
	
	if(L.first != NULL){
		//list tidak kosong
		eBaris *elmt;
		
		//inisialisasi
		elmt = L.first;
		while(elmt != NULL){
			//proses
			hasil++;
			//iterasi
			elmt = elmt->next;
		}
	}
	return hasil;
}

int countElementK(eBaris L){
	
	int hasil = 0;
	
	if(L.co1 != NULL){
		//list tidak kosong
		eKolom *elmt;
		
		//inisialisasi
		elmt = L.co1;
		
		while(elmt != NULL){
			//proses
			hasil = hasil +1;
			
			//iterasi
			elmt = elmt->next;
		}
	}
	return hasil;
}

void addFirstB(char nim[],  list*L){
	eBaris *elmt;
	elmt = (eBaris *) malloc (sizeof(eBaris));
	strcpy(elmt->elmt.nim, nim);
	elmt->co1 = NULL;
	if((*L).first = NULL){
		elmt->next = NULL;
	}
	else{
		elmt->next = (*L).first;
	}
	(*L).first = elmt;
	elmt = NULL;
}

void addFirstK(char kode[],  eBaris *L){
	eKolom *elmt;
	elmt = (eKolom *) malloc(sizeof(eKolom));
	strcpy(elmt->elmt.kode, kode);
	if((*L).co1 == NULL){
		elmt->next = NULL;
	}
	else{
		elmt->next = (*L).co1;
	}
	(*L).co1 = elmt;
	elmt = NULL;
}

void addAfterB(eBaris *prev, char nim[]){
	
	eBaris *elmt;
	elmt = (eBaris *) malloc (sizeof (eBaris));
	strcpy(elmt->elmt.nim, nim);
	elmt->co1 = NULL;
	if(prev->next = NULL){
		elmt->next = NULL;
	}
	else{
		elmt->next = prev->next;
	}
	prev->next = elmt;
	elmt = NULL;
}

void addAfterK(eKolom *prev, char kode[]){
	
	eKolom *elmt;
	elmt = (eKolom *) malloc(sizeof(eKolom));
	strcpy(elmt->elmt.kode, kode);
	if(prev->next = NULL){
		elmt->next = NULL;
	}
	else{
		elmt->next = prev->next;
	}
	prev->next = elmt;
	elmt = NULL;
}

void addLastB(char nim[],  list *L){
	if((*L).first == NULL){
		//jika list adalah list kosong
		addFirstB(nim, L);
	}
	else{
		//jika list tidak kosong
		eBaris *elmt;
		elmt = (eBaris *) malloc(sizeof(eBaris));
		strcpy(elmt->elmt.nim, nim);
		elmt->next = NULL;
		elmt->co1 = NULL;
		//mencari elemen terakhir
		
		eBaris *last = (*L).first;
		while(last->next != NULL){
			//iterasi
			last = last->next;
		}
	last->next = elmt;
	elmt = NULL;
	}
}

void addLastK(char kode[],  eBaris *L){
	if((*L).co1 == NULL){
		//jika list adalah list kosong
		addFirstK(kode, L);
	}
	else{
		//jika list tidak kosong
		eKolom *elmt;
		elmt = (eKolom *) malloc(sizeof(eKolom));
		strcpy(elmt->elmt.kode, kode);
		elmt->next = NULL;
		//mencari elemen terakhir
		
		eKolom *last = (*L).co1;
		while(last->next != NULL){
			//iterasi
			last = last->next;
		}
	last->next = elmt;
	elmt = NULL;
	}
}

void delFirstB(list *L){
	if((*L).first != NULL){
		//jika list bukan list kosong
		eBaris *elmt = (*L).first;
		if(countElementB(*L) == 1){
			(*L).first = NULL;
		}
		else{
			(*L).first = (*L).first->next;
			elmt->next = NULL;
		}
		free(elmt);
	}
}

void delFirstK(eBaris *L){
	if((*L).co1 != NULL){
		//jika list bukan list kosong
		eKolom *elmt = (*L).co1;
		if(countElementK(*L) == 1){
			(*L).co1 = NULL;
		}
		else{
			(*L).co1 = (*L).co1->next;
			elmt->next = NULL;
		}
		free(elmt);
	}
}

void delAfterB(eBaris *prev){
	eBaris *elmt = prev->next;
	if(elmt->next == NULL){
		prev->next = NULL;
	}
	else{
		prev->next = elmt->next;
		elmt->next = NULL;
	}
	free(elmt);
}

void delAfterK(eKolom *prev){
	eKolom *elmt = prev->next;
	if(elmt->next == NULL){
		prev->next = NULL;
	}
	else{
		prev->next = elmt->next;
		elmt->next = NULL;
	}
	free(elmt);
}

void delLastB(list *L){
	if((*L).first != NULL){
		//jika list tidak kosong
		if(countElementB(*L) == 1){
			//list terdiri dari satu elemen
			delFirstB(L);
		}
		else{
			//mencari elemen terakhir list
			eBaris *last = (*L).first;
			eBaris *before_last = NULL;
			
			while(last->next != NULL){
				//iterasi
				before_last = last;
				last = last->next;
			}
			before_last->next = NULL;
			free(last);
		}
	}
}

void delLastK(eBaris *L){
	if((*L).co1 != NULL){
		//jika list tidak kosong
		if(countElementK(*L) == 1){
			//list terdiri dari satu elemen
			delFirstK(L);
		}
		else{
			//mencari elemen terakhir list
			eKolom *last = (*L).co1;
			eKolom *before_last;
			
			while(last->next != NULL){
				//iterasi
				before_last = last;
				last = last->next;
			}
			before_last->next = NULL;
			free(last);
		}
	}
}

void printElement(list L){
	if(L.first != NULL){
		eBaris *elmt = L.first;
		int i = 1;
		
		while(elmt != NULL){
			//proses
			printf("%s\n", elmt->elmt.nim);
			eKolom *eCo1 = elmt->co1;
			while(eCo1 != NULL){
				printf("%s\n", eCo1->elmt.kode);
				eCo1 = eCo1->next;
			}
			//iterasi
			elmt = elmt->next;
			i++;
		}
	}
	else{
		//jika list kosong
		printf("list kosong\n");
	}
}

void delAllB(list *L){
	if(countElementB(*L) != 0){
		int i;
		
		for(i=countElementB(*L) ; i>=1 ; i--){
			delLastB(L);
		}
	}
}

void delAllK(eBaris *L){
	if(countElementK(*L) != 0){
		int i;
		
		for(i=countElementK(*L) ; i>=1 ; i--){
			delLastK(L);
		}
	}
}