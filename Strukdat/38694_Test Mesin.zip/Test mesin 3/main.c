#include "header.h"

int main(){
	list L;
	createList(&L);
	ubar ubaran[5];
	int i;
	for(i=0 ; i<5 ; i++){
		scanf(" %s %s %s", ubaran[i].obat, ubaran[i].stok, ubaran[i].harga);
	}
	
	addLast(ubaran[0].obat, ubaran[0].stok, ubaran[0].harga, &L);
	addFirst(ubaran[1].obat, ubaran[1].stok, ubaran[1].harga, &L);
	addAfter(L.data[L.first].next, ubaran[2].obat, ubaran[2].stok, ubaran[2].harga ,&L);
	
	printElement(L);
	printf("======\n");
	addFirst(ubaran[3].obat, ubaran[3].stok, ubaran[3].harga, &L);
	delAfter(L.first, &L);
	
	printElement(L);

	printf("======\n");

	addLast(ubaran[4].obat, ubaran[4].stok, ubaran[4].harga, &L);
	printElement(L);
	printf("======\n");
	printtohead(L);
	printf("======\n");
	
	delFirst(&L);
	delLast(&L);
	printElement(L);
	printf("======\n");
	return 0;
}