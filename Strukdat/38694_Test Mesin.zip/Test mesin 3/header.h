#include <stdio.h>
#include <string.h>

typedef struct{
	char obat[20];
	char stok[5];
	char harga[20];
}ubar;

typedef struct{
	ubar elmt;
	int prev;
	int next;
}elemen;

typedef struct{
	int first;
	int tail;
	elemen data[10];
}list;

void createList(list *L);
int countElement(list L);
int emptyElement(list L);
void addFirst(char obat[],char stok[], char harga[], list *L);
void addAfter(int prev, char obat[], char stok[], char harga[], list *L);
void addLast(char obat[], char stok[], char harga[], list *L);
void delFirst(list *L);
void delAfter(int prev, list *L);
void delLast(list *L);
void printElement(list L);
void delAll(list *L);
void printtohead(list L);