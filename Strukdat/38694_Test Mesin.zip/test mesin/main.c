#include "header.h"

int main(){
	list L;
	createList(&L);
	biodat nami[5];
	int i;
	
	for(i=0 ; i<5 ; i++){
		scanf("%s %d %s", &nami[i].nama, &nami[i].umur, &nami[i].jk);
	}
	
	addFirst(nami[0].nama, nami[0].umur, nami[0].jk, &L);
	addFirst(nami[1].nama, nami[1].umur, nami[1].jk, &L);
	addLast(nami[2].nama, nami[2].umur, nami[2].jk, &L);
	delLast(&L);
	printElement(L);
	printf("======\n");
	addAfter(L.data[L.data[L.first].next].next,nami[3].nama, nami[3].umur, nami[3].jk, &L);
	printElement(L);
	printf("======\n");
	addFirst(nami[4].nama, nami[4].umur, nami[4].jk, &L);
	delAfter(L.first, &L);
	delLast(&L);
	printElement(L);
	delAll(&L);
	printf("======\n");
	printElement(L);
	printf("======\n");
	
	return 0;
}