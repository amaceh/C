#include "header.h"

void createList(list *L){
	(*L).first = -1;
	int i;
	for(i=0 ; i<10 ; i++){
		//proses inisialisasi array
		(*L).data[i].next = -2;
	}
}

int countElement(list L){
	int hasil = 0;
	if(L.first != -1){
		//list tidak kosong
		int jalmi;
		//inisialisasi
		jalmi = L.first;
		
		while(jalmi != -1){
			//proses
			hasil = hasil + 1;
			//iterasi
			jalmi = L.data[jalmi].next;
		}
	}
	return hasil;
}

int tanahkosong(list L){
	int hasil = -1;
	
	if(countElement(L) < 10){
		int ketemu=0;
		int i=0;
		
		while((ketemu == 0)&& (i<10)){
			if(L.data[i].next == -2){
				hasil = i;
				ketemu = 1;
			}
			else{
				i = i + 1;
			}
		}
	}
	return hasil;
}

void addFirst(char nama[], int umur, char jk[], list *L){
	if(countElement(*L) < 10){
		int baru  = tanahkosong(*L);
		strcpy((*L).data[baru].jalmi.nama, nama);
		(*L).data[baru].jalmi.umur = umur;
		strcpy((*L).data[baru].jalmi.jk, jk);
		
		if((*L).first == -1){
			//jika list kosong maka
			(*L).data[baru].next =-1;
		}
		else{
			//jika tidak kosong maka
			(*L).data[baru].next=(*L).first;
		}
		(*L).first=baru;
	}
	else{
		//proses jika array penuh
		printf("sudah tidak dapat ditambah\n");
	}
}

void addAfter(int prev, char nama[], int umur, char jk[], list *L){
	if(countElement(*L) < 10){
		int baru  = tanahkosong(*L);
		strcpy((*L).data[baru].jalmi.nama, nama);
		(*L).data[baru].jalmi.umur = umur;
		strcpy((*L).data[baru].jalmi.jk, jk);
		
		if((*L).data[prev].next == -1){
			//jika list kosong maka
			(*L).data[baru].next =-1;
		}
		else{
			//jika tidak kosong maka
			(*L).data[baru].next=(*L).data[prev].next;
		}
		(*L).data[prev].next=baru;
	}
	else{
		//proses jika array penuh
		printf("sudah tidak dapat ditambah\n");
	}
}

void addLast(char nama[], int umur, char jk[], list *L){
	if((*L).first == -1){
		//proses jika list masih kosong
		addFirst(nama,umur,jk,L);
	}
	else{
		//proses jika list telah berisi
		if(countElement(*L) < 10){
			//proses jika array belum penuh
			/*proses mencari elemen terakhir*/
			//inisialisasi
			int prev = (*L).first;
			
			while((*L).data[prev].next != -1){
				//iterasi
				prev = (*L).data[prev].next;
			}
			addAfter(prev,nama,umur,jk,L);
		}
		else{
			//proses jika array penuh
			printf("sudah tidak dapat ditambah\n");
		}
	}
}

void delFirst(list *L){
	if((*L).first != 1){
		int hapus = (*L).first;
		if(countElement(*L) == 1){
			(*L).first = -1;
		}
		else{
			(*L).first = (*L).data[(*L).first].next;
		}
		//elemen awal sebelumnya dikosongkan
		(*L).data[hapus].next = -2;
	}
	else{
		//proses list jika list kosong
		printf("list kosong\n");
	}
}

void delAfter(int prev, list *L){
	int  hapus = (*L).data[prev].next;
	
	if(hapus != -1){
		if((*L).data[hapus].next == -1){
			(*L).data[prev].next = -1;
		}
		else{
			(*L).data[prev].next = (*L).data[hapus].next;
		}
		//pengosongan elemen
		(*L).data[hapus].next = -2;
	}
}

void delLast(list *L){
	if((*L).first != -1){
		if(countElement(*L) == 1){
			//proses jika list hanya berisi satu elemen
			delFirst(L);
		}
		else{
			int hapus = (*L).first;
			int prev;
			while((*L).data[hapus].next != -1){
				//iterasi
				prev = hapus;
				hapus = (*L).data[hapus].next;
			}
			//elemen sebelum elemen terakhir menjadi elemen terakhir
			delAfter(prev, L);
		}
	}
	else{
		//proses jika list kosong
		printf("List Kosong!\n");
	}
}

void printElement(list L){
	if(L.first != -1){
		int jalmi = L.first;
		int i = 1;
		while(jalmi != -1){
			//proses
			printf("%s %d %s\n", L.data[jalmi].jalmi.nama, L.data[jalmi].jalmi.umur, L.data[jalmi].jalmi.jk);
			//iterasi
			jalmi = L.data[jalmi].next;
			i++;
		}
	}
	else{
		printf("List Kosong!\n");;
	}
}

void delAll(list *L){
	int i;
	for(i = countElement(*L); i >= 1; i--){
		//proses menghapus elemen list
		delLast(L);
	}
}