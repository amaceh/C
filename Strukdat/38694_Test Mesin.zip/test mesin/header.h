#include <stdio.h>
#include <string.h>

typedef struct{
	char nama[10];
	int umur;
	char jk[3];
}biodat;

typedef struct{
	biodat jalmi;
	int next;
}elemen;

typedef struct{
	int first;
	elemen data[10];
}list;

void createList(list *L);
int countElement(list L);
int tanahkosong(list L);
void addFirst(char nama[], int umur, char jk[], list *L);
void addAfter(int prev, char nama[], int umur, char jk[], list *L);
void addLast(char nama[], int umur, char jk[], list *L);
void delFirst(list *L);
void delAfter(int prev, list *L);
void delLast(list *L);
void printElement(list L);
void delAll(list *L);