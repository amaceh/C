#include "header.h"

int main(){
	list L;
	createList(&L);
	galaxy bima[6];
	int i;
	for(i = 0 ; i<6 ; i++){
		scanf("%s %s", &bima[i].bintang, &bima[i].konstelasi);
	}
	addFirst(bima[0].bintang, bima[0].konstelasi, &L);
	addFirst(bima[1].bintang, bima[1].konstelasi, &L);
	addAfter(L.first, bima[2].bintang, bima[2].konstelasi, &L);
	printElement(L);
	printf("-----\n");
	
	delAfter(L.first->next->prev, &L);
	addLast(bima[3].bintang, bima[3].konstelasi, &L);
	printElement(L);
	printf("-----\n");
	
	delFirst(&L);
	addLast(bima[4].bintang, bima[4].konstelasi, &L);
	addAfter(L.first->next, bima[5].bintang, bima[5].konstelasi, &L);
	delLast(&L);
	printtohead(L);
	printf("-----\n");
	
	return 0;
}