#include "header.h"

//prosedur untuk create list
void createList(list *L){
	(*L).first = NULL; //null harus kapital
	(*L).tail = NULL;
}

int countElement(list L){
	int hasil = 0;
	
	if(L.first != NULL){
		//list tidak kosong
		elemen *elmt;
		
		//inisialisasi
		elmt = L.first;
		
		while(elmt != NULL){
			//proses
			hasil++;
			
			//iterasi
			elmt = elmt->next;
		}
	}
	return hasil;
}

void addFirst(char bintang[], char konstelasi[], list *L){
	elemen *baru;
	//memaksa memori untuk bisa mengakses pointer elemen, sehingga (elemen *)
	baru = (elemen *) malloc (sizeof (elemen));
	
	//mengisi data2 nya
	strcpy(baru->elmt.bintang, bintang);
	strcpy(baru->elmt.konstelasi, konstelasi);
	
	//memeriksa jika tidak ada elemen
	if((*L).first == NULL){
		baru->prev = NULL;
		baru->next = NULL;
		(*L).tail = baru;
	}
	//jika ada elemen
	else{
		baru->next = (*L).first;
		baru->prev = NULL;
		(*L).first->prev = baru;
	}
	(*L).first = baru;
	baru = NULL;
}
void addAfter(elemen *prev, char bintang[], char konstelasi[], list *L){
	elemen *baru;
	//memaksa memori untuk bisa mengakses pointer elemen, sehingga (elemen *)
	baru = (elemen *) malloc (sizeof (elemen));
	
	//mengisi data2 nya
	strcpy(baru->elmt.bintang, bintang);
	strcpy(baru->elmt.konstelasi, konstelasi);
	
	//memeriksa jika tidak ada elemen
	if(prev->next == NULL){
		baru->next = NULL;
		(*L).tail = baru;
	}
	//jika ada elemen
	else{
		baru->next = prev->next;
		baru->next->prev = baru; //tangan prev dari nextnya baru di pindah ke baru
	}
	baru->prev = prev;
	prev->next = baru;
	baru = NULL; 
}

void addLast(char bintang[], char konstelasi[], list *L){
	if((*L).first == NULL){
		//jika list kosong
		addFirst(bintang, konstelasi, L);
	}
	else{
		//jika list tidak kosong
		//mencari elemen terakhir list
		elemen *prev = (*L).first;
		while(prev->next != NULL){
			//iterasi
			prev = prev->next;
		}
		addAfter(prev, bintang, konstelasi, L);
	}
}

void delFirst(list *L){
	if((*L).first != NULL){
		//jika list tidak kosong
		elemen *hapus = (*L).first;
		
		if(countElement(*L) == 1){
			(*L).first = NULL;
			(*L).tail = NULL;
		}
		else{
			(*L).first = (*L).first->next;
			(*L).first->prev = NULL;
			hapus->next = NULL;
		}
		//untuk menghapus yang ada di memori agar bisa dipakai lagi
		free(hapus);
	}
}

void delAfter(elemen *prev, list *L){
	elemen *hapus = prev->next;
	if(hapus != NULL){
		if(hapus->next == NULL){
			//jika elemen yang dihapus ada diakhir
			prev->next = NULL;
		}
		else{
			prev->next = hapus->next;
			hapus->next->prev = prev;
			hapus->next = NULL;		
		}
	hapus->prev = NULL;
	free(hapus);
	}
}

void delLast(list *L){
	if((*L).first != NULL){
		//jika list tidak kosong
		if(countElement(*L) == 1){
			//list terdiri dari satu elemen
			delFirst(L);
		}
		else{
			//mencari lemen terakhir list
			//last -> membuat baru
			elemen *hapus = (*L).tail;
			(*L).tail = hapus->prev;
			(*L).tail->next = NULL;
			hapus->prev = NULL;
			free(hapus);
		}
	}
}

void printElement(list L){
	if(L.first != NULL){
		//jika list tidak kosong
		//inisialisasi
		elemen *elmt = L.first;
		int i = 1;
		while(elmt != NULL){
			//proses
			printf("%s %s\n", elmt->elmt.bintang, elmt->elmt.konstelasi);
			
			//iterasi
			elmt = elmt->next;
			i++;
		}
	}
	else{
		//proses jika list kosong
		printf("list kosong\n");
	}
}

void delAll(list *L){
	int i;
	
	for(i=countElement(*L); i>=1 ; i--){
		//proses menghapus elemen list
		delLast(L);
	}
}

void printtohead(list L){
	if(L.tail != NULL){
		//jika list tidak kosong
		//inisialisasi
		elemen *elmt = L.tail;
		int i = 1;
		while(elmt != NULL){
			//proses
			printf("%s %s\n", elmt->elmt.bintang, elmt->elmt.konstelasi);
			
			//iterasi
			elmt = elmt->prev;
			i++;
		}
	}
	else{
		//proses jika list kosong
		printf("list kosong\n");
	}
}